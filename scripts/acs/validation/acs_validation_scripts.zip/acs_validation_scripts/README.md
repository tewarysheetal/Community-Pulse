# ACS validation scripts

Place these files under:

```text
scripts/acs/validation/
```

Expected Python packages:

```bash
pip install pandas psycopg2-binary python-dotenv
```

These scripts use:
- `load_dotenv()`
- `DB_HOST`
- `DB_PORT`
- `DB_NAME`
- `DB_USER`
- `DB_PASSWORD`

Optional:
- `DB_SCHEMA` defaults to `public`

## Run order

```bash
python scripts/acs/validation/01_validate_stg_tables.py
python scripts/acs/validation/02_validate_int_tables.py
python scripts/acs/validation/03_validate_fact_tables.py
```

Or run everything:

```bash
python scripts/acs/validation/04_run_full_validation.py
```

## Output folders

```text
outputs/acs/validation/stg/
outputs/acs/validation/int/
outputs/acs/validation/fact/
outputs/acs/validation/summary/
```
